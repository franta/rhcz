<?php
/**
* $user full object
* $user->link -- link to href for term  - l($term->name, $term->path, array('attributes' => array('class' => "cctags vid$item->vid level$term->level depth$term->depth node-counts$term->nodecnt", 'rel' => 'tag')))
*/
?>
<?php print $user->link.' '; ?>