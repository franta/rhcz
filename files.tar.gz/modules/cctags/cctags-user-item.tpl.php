<?php
/**
* $user full object --- user_load($user->uid)
* $user->link  -- link to href for term  - l($term->name, $term->path, array('attributes' => array('class' => "cctags vid$item->vid level$term->level depth$term->depth node-counts$term->nodecnt", 'rel' => 'tag')))
* $user->node_count -- counts nodes publish of this user
* $user->comment_count -- counts comments of this user
* $name - theme('username', $user);
* $picture - theme('user_picture', $user);
*/
?>
<div class="cctags cctags-user-item">
<?php print $name; ?>
<?php if ($user->picture) { ?><div class="cctags picture"><?php print  $picture; ?></div><?php } ?>
<div class="clear" />
</div> <!-- // cctags cctags-user-item -->