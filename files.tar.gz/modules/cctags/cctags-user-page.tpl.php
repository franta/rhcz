<?php
/*
*  $content -- cctags content (amount users for per page)
*  $pager   -- if amount < count all terms view pager
*/
?>
<div class="cctags cctags-user-page wrapper"><?php print $content; ?></div><!-- // cctags cctags-user-page wrapper -->
<div class="pager"><?php print $pager; ?></div><!-- // pager -->