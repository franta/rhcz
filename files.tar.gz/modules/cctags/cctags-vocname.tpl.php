<?php
/**
* $vocname 	-- array vocabulary name
* $vid   	-- array vocabulary vid
* $terms   	-- array counts terms in current vocabulary
*/
?>
<div class="clear-block">
<?php if(isset($vocname)) { ?>
<div class="cctags vocname">
<?php $i=0; foreach($vocname as $key => $name) {
if ($i>0) {$vname = '::'.$name;}
else {$vname = $name;}
$i++;
?>
<span class="cctags vocname vid-<?php print $vid[$key];?>"><?php print $vname; ?></span>
<?php } ?>
</div>
<?php } ?>
</div>
